//HeapPriorityQueue.cpp
#ifndef _HEAPPRIORITYQUEUE_CPP
#define _HEAPPRIORITYQUEUE_CPP

#include "HeapPriorityQueue.hpp"
#include <cassert>
#include <cstdlib>//for NULL
#include <iostream>

HeapPriorityQueue::HeapPriorityQueue() {
  // TODO
}

HeapPriorityQueue::~HeapPriorityQueue() {
  // TODO
}

void HeapPriorityQueue::add(PuzzleState *elem) {
  // TODO
}

PuzzleState * HeapPriorityQueue::remove() {
  // TODO
}


PuzzleState *HeapPriorityQueue::get_next() {
  // TODO
}

bool HeapPriorityQueue::is_empty() {
  // TODO
}

#endif

//LinkedListQueue.cpp
#ifndef _LINKEDLISTQUEUE_CPP
#define _LINKEDLISTQUEUE_CPP

#include "LinkedListQueue.hpp"
#include <cstdlib> //for NULL
#include <cassert>
#include <iostream>
LinkedListQueue::LinkedListQueue()
{
  // TODO
}

void LinkedListQueue::add(PuzzleState *elem)
{
  // TODO
}

PuzzleState *LinkedListQueue::remove()
{
  // TODO
}

bool LinkedListQueue::is_empty()
{
  // TODO
}

LinkedListQueue::~LinkedListQueue()
{
  // TODO
}

#endif

